/* Renderizador compartilhado por celulares, PCs e telão.  Sem bibliotecas externas. */
(() => {
  const TAU = Math.PI * 2;
  const palette = ['#B96CFF','#53E6D1','#F7CB65','#FD77B6','#6BB9FF','#B8EF73','#FF946F','#F3F0FF'];
  const grid = 80;
  const renderer = {};
  renderer.fit = function(canvas) {
    const box = canvas.getBoundingClientRect();
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.7);
    const w = Math.max(1, Math.round(box.width * pixelRatio));
    const h = Math.max(1, Math.round(box.height * pixelRatio));
    if(canvas.width !== w || canvas.height !== h) {canvas.width = w; canvas.height = h;}
    return {ctx:canvas.getContext('2d'), w:box.width,h:box.height,dpr:pixelRatio};
  };
  renderer.draw = function(canvas, state, focusId, host=false, camera={}) {
    const box=renderer.fit(canvas), {ctx,w,h,dpr}=box;
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,w,h);
    ctx.fillStyle='#100b1c';ctx.fillRect(0,0,w,h);
    if(!state) return;
    // Smooth authoritative snapshots; do not predict collisions or scores.
    const stamp=performance.now(), dt=Math.min(.1,(stamp-(camera.stamp||stamp))/1000);
    camera.stamp=stamp;camera.positions??={};
    const alpha=1-Math.exp(-dt*24);
    const players=state.players.map(p=>{
      let old=camera.positions[p.id];
      if(!old||!p.alive||Math.hypot(p.x-old.x,p.y-old.y)>180)old={x:p.x,y:p.y};
      const x=old.x+(p.x-old.x)*alpha,y=old.y+(p.y-old.y)*alpha;
      camera.positions[p.id]={x,y};
      return {...p,x,y};
    });
    const active=new Set(players.map(p=>p.id));
    for(const id of Object.keys(camera.positions))if(!active.has(id))delete camera.positions[id];
    const W=state.width||2200,H=state.height||1400;
    const player=players.find(p=>p.id===focusId);
    const zoom=host ? Math.min((w-20)/W,(h-20)/H) : Math.min(1.25,Math.max(.68,Math.min(w/510,h/700)));
    const targetX=host? W/2:player?.x??W/2;
    const targetY=host? H/2:player?.y??H/2;
    camera.x = camera.x===undefined ? targetX : camera.x+(targetX-camera.x)*(host?1:.16);
    camera.y = camera.y===undefined ? targetY : camera.y+(targetY-camera.y)*(host?1:.16);
    ctx.save();ctx.translate(w/2,h/2);ctx.scale(zoom,zoom);ctx.translate(-camera.x,-camera.y);
    ctx.fillStyle='#171025';ctx.fillRect(0,0,W,H);
    ctx.strokeStyle='#2a1b3d';ctx.lineWidth=1;
    ctx.beginPath();for(let x=0;x<=W;x+=grid){ctx.moveTo(x,0);ctx.lineTo(x,H);}
    for(let y=0;y<=H;y+=grid){ctx.moveTo(0,y);ctx.lineTo(W,y);}ctx.stroke();
    ctx.strokeStyle='#9A51EB';ctx.shadowBlur=18;ctx.shadowColor='#a24eff';ctx.lineWidth=7;ctx.strokeRect(3,3,W-6,H-6);ctx.shadowBlur=0;
    const t=performance.now()/1000;
    for(const item of state.food || []) {
      const [id,x,y,kind]=item;
      const color=kind===2?'#f9cf6d':kind===1?'#54ebd5':'#aa73ee';
      const r=kind===2?8:kind===1?6:4;
      ctx.globalAlpha=.6+.3*Math.sin(t*2+id);
      ctx.fillStyle=color;ctx.shadowColor=color;ctx.shadowBlur=kind===2?18:12;
      ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();ctx.shadowBlur=0;
      if(kind===2){ctx.strokeStyle='#ffe9aa';ctx.lineWidth=1.4;ctx.stroke();}
    }ctx.globalAlpha=1;
    for(const p of players){
      if(!p.alive || !p.trail?.length)continue;
      ctx.save();
      if(p.shield)ctx.globalAlpha=.68;
      const pts=[...p.trail].reverse();
      if(pts.length>=2){
        ctx.lineJoin='round';ctx.lineCap='round';
        ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);
        for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);
        ctx.strokeStyle=p.color;ctx.lineWidth=19;
        ctx.shadowColor=p.color;ctx.shadowBlur=15;ctx.stroke();ctx.shadowBlur=0;
        ctx.strokeStyle='#ffffff';ctx.globalAlpha=p.shield ? .14 : .17;ctx.lineWidth=5;ctx.stroke();ctx.globalAlpha=p.shield ? .68 : 1;
      }
      ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=23;
      ctx.beginPath();ctx.arc(p.x,p.y,11,0,TAU);ctx.fill();ctx.shadowBlur=0;
      const dx=Math.cos(p.angle),dy=Math.sin(p.angle),perpX=-dy,perpY=dx;
      ctx.fillStyle='#fff';
      for(const side of [-1,1]){ctx.beginPath();ctx.arc(p.x+dx*5+perpX*side*5,p.y+dy*5+perpY*side*5,2.4,0,TAU);ctx.fill();}
      if(p.shield){ctx.strokeStyle='#e7d2ff';ctx.lineWidth=2;ctx.setLineDash([5,5]);ctx.beginPath();ctx.arc(p.x,p.y,25+Math.sin(t*8)*2,0,TAU);ctx.stroke();ctx.setLineDash([]);}
      ctx.globalAlpha=1;
      const label=p.name.length>18?p.name.slice(0,18):p.name;
      ctx.font='700 13px system-ui';ctx.textAlign='center';ctx.textBaseline='bottom';
      ctx.strokeStyle='#10091d';ctx.lineWidth=4;ctx.strokeText(label,p.x,p.y-19);
      ctx.fillStyle=focusId===p.id?'#fff':p.color;ctx.fillText(label,p.x,p.y-19);
      if(focusId===p.id){ctx.strokeStyle='#fff';ctx.globalAlpha=.26;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(p.x,p.y,34,0,TAU);ctx.stroke();}
      ctx.restore();
    }
    ctx.restore();
    const grad=ctx.createRadialGradient(w/2,h/2,0,w/2,h/2,Math.max(w,h)*.75);
    grad.addColorStop(0,'rgba(8,5,15,0)');grad.addColorStop(1,'rgba(8,5,15,.37)');
    ctx.fillStyle=grad;ctx.fillRect(0,0,w,h);
    return camera;
  };
  renderer.colors=palette;
  renderer.clock=(milliseconds)=>{
    const s=Math.max(0,Math.ceil(milliseconds/1000));
    return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
  };
  renderer.text=(tag,cls,content)=>{const n=document.createElement(tag);if(cls)n.className=cls;n.textContent=String(content);return n;};
  window.CyberRender=renderer;
})();
